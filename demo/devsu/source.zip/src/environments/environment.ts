export const environment = {
  baseUrl: "https://tribu-ti-staffing-desarrollo-afangwbmcrhucqfh.z01.azurefd.net/ipf-msa-productosfinancieros",
  authorId: "281"
};

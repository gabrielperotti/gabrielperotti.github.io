import { Component } from '@angular/core';

@Component({
  selector: 'app-form-skeleton',
  standalone: true,
  imports: [],
  templateUrl: './form-skeleton.component.html',
  styleUrl: './form-skeleton.component.css'
})
export class FormSkeletonComponent {

}
